#!/bin/bash
set -ueo pipefail

source ~/variables.sh

BACKUP_METRICS=${WORKING_DIR}/backup-metrics
# restore metrics
metrics="prometheus-9090 grafana-3000 alertmanager-9093 monitor-9100"
if [ -d "${BACKUP_METRICS}" ]; then
    for i in $metrics; do
        echo restore $i
        rm -rf ${DEPLOY_DIR}/$i
        cp -rf ${BACKUP_METRICS}/$i ${DEPLOY_DIR}/
    done
else
    echo no backup found for metrics
fi
