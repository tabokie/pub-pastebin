#!/bin/bash
# synchronize tidb/pd binary and config
set -eof pipefail

source ~/variables.sh

TIDB_TARGET="${USER_NAME}@${TIDB}"
TIDB_DIR="${DEPLOY_DIR}/tidb-4000"
PD_TARGET=$TIDB_TARGET
PD_DIR="${DEPLOY_DIR}/pd-2379"

SUFFIX="-${1}"
if [ -z "${1}" ]; then
    SUFFIX=""
fi

for i in $TIDB_TARGET; do
    if [ -e ${BINARY_DIR}/tidb-server${SUFFIX} ]; then
        echo sync tidb-server${SUFFIX} to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/tidb-server${SUFFIX} $i:${TIDB_DIR}/bin/tidb-server
    elif [ -e ${BINARY_DIR}/tidb-server ]; then
        echo sync tidb-server to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/tidb-server $i:${TIDB_DIR}/bin/tidb-server
    fi
    if [ -e ${BINARY_DIR}/tidb${SUFFIX}.toml ]; then
        echo sync tidb${SUFFIX}.toml to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/tidb${SUFFIX}.toml $i:${TIDB_DIR}/conf/tidb.toml
    elif [ -e ${BINARY_DIR}/tidb.toml ]; then
        echo sync tidb.toml to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/tidb.toml $i:${TIDB_DIR}/conf/tidb.toml
    fi
done
for i in $PD_TARGET; do
    echo sync pd to $i
    if [ -e ${BINARY_DIR}/pd-server${SUFFIX} ]; then
        echo sync pd-server${SUFFIX} to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/pd-server${SUFFIX} $i:${PD_DIR}/bin/pd-server
    elif [ -e ${BINARY_DIR}/pd-server ]; then
        echo sync pd-server to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/pd-server $i:${PD_DIR}/bin/pd-server
    fi
    if [ -e ${BINARY_DIR}/pd${SUFFIX}.toml ]; then
        echo sync pd${SUFFIX}.toml to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/pd${SUFFIX}.toml $i:${PD_DIR}/conf/pd.toml
    elif [ -e ${BINARY_DIR}/pd.toml ]; then
        echo sync pd.toml to $i
        scp ${SSH_FLAGS} ${BINARY_DIR}/pd.toml $i:${PD_DIR}/conf/pd.toml
    fi
done
