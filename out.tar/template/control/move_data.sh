#!/bin/bash
set -ueo pipefail

SOURCE=/data/deploy/tikv-20160/data/db
TARGET=/backup/db_tmp
NUM=10000

mkdir -p ${TARGET}
i=0
for file in ${SOURCE}/*; do
    if [ "$i" = "$NUM" ]; then
        exit 0
    fi
    if [[ -L ${file} ]]; then
        echo "skip link"
        continue
    fi
    i=$((i+1))
    name=`basename "${file}"`
    echo "sending" ${name}
    mv ${file} ${TARGET}/${name}
    ln -s ${TARGET}/${name} ${file}
done
