#!/bin/bash
set -ueo pipefail

source ~/variables.sh

BACKUP_METRICS=${WORKING_DIR}/backup-metrics
# backup metrics
mkdir -p ${BACKUP_METRICS}
metrics="prometheus-9090 grafana-3000 alertmanager-9093 monitor-9100"
for i in $metrics; do
    echo backup $i
    rm -rf ${BACKUP_METRICS}/$i
    cp -rf ${DEPLOY_DIR}/$i ${BACKUP_METRICS}/
done
