sudo yum install -y elfutils-libelf-devel gcc git wget
git clone https://github.com/tabokie/EnhanceIO.git -b aws
cd EnhanceIO
# CLI
sudo cp CLI/eio_cli /sbin/
sudo chmod 700 CLI/eio_cli
sudo cp CLI/eio_cli.8 /usr/share/man/man8
# driver
# install kernel-devel
wget https://linuxsoft.cern.ch/cern/centos/7/updates/x86_64/Packages/kernel-devel-$(uname -r).rpm
sudo rpm -i kernel-devel-$(uname -r).rpm
cd Driver/enhanceio
make -j4 && sudo make install
sudo modprobe enhanceio_fifo
sudo modprobe enhanceio_lru
sudo modprobe enhanceio
