#!/bin/bash
set -ueo pipefail

source ~/variables.sh
tiup cluster destroy ${TIUP_NAME} -y || true
tiup cluster deploy ${TIUP_NAME} nightly ./topology.yaml --user ${USER_NAME} -i ${SSH_KEY} -y
