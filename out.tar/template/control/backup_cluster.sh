#!/bin/bash
set -ueo pipefail

source ~/variables.sh
SUFFIX="-${1}"
if [ -z "${1}" ]; then
    SUFFIX=""
fi

BACKUP_SUBDIR=${BACKUP_DIR}/backup${SUFFIX}
CMD="rm -rf ${BACKUP_SUBDIR} && mkdir -p ${BACKUP_SUBDIR} && cp -rf ${DEPLOY_DIR} ${BACKUP_SUBDIR}/data"
for i in ${TIKV}; do
    echo backup tikv on $i
    nohup ssh $SSH_FLAGS $i "${CMD}" &
done
# backup pd
others="pd-2379 tidb-4000"
mkdir -p ${WORKING_DIR}/backup${SUFFIX}
for i in $others; do
    echo backup $i
    rm -rf ${WORKING_DIR}/backup${SUFFIX}/$i
    cp -rf ${DEPLOY_DIR}/$i ${WORKING_DIR}/backup${SUFFIX}/
done
wait
