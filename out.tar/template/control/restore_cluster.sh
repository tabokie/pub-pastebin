#!/bin/bash
set -ueo pipefail

source ~/variables.sh
SUFFIX="-${1}"
if [ -z "${1}" ]; then
    SUFFIX=""
fi

BACKUP_SUBDIR=${BACKUP_DIR}/backup${SUFFIX}
CMD="mkdir -p ${DEPLOY_DIR} && rm -rf ${DEPLOY_DIR}/tikv-20160 && cp -rf ${BACKUP_SUBDIR}/data/tikv-20160 ${DEPLOY_DIR}/"
for i in ${TIKV}; do
    echo restore tikv on $i
    nohup ssh $SSH_FLAGS $i "${CMD}" &
done
# restore pd
others="pd-2379 tidb-4000"
for i in $others; do
    echo restore $i
    rm -rf ${DEPLOY_DIR}/$i
    cp -rf ${WORKING_DIR}/backup${SUFFIX}/$i ${DEPLOY_DIR}/
done
wait
