#!/bin/bash
source ~/variables.sh
mysql -u root -h ${TIDB} -P 4000
