#!/bin/bash
set -ueo pipefail

source ~/variables.sh

./deploy.sh
./sync_cluster.sh ${1}
./sync_tikv.sh ${1}
./restore_metrics.sh
tiup cluster start ${TIUP_NAME}
mysql -u root -h ${TIDB} -P 4000 --execute="set @@global.tidb_enable_clustered_index = '1';"
mysql -u root -h ${TIDB} -P 4000 --execute="set global tidb_hashagg_final_concurrency=1;set global tidb_hashagg_partial_concurrency=1;set global tidb_disable_txn_auto_retry=0;"
sleep 5

go-tpc tpcc --warehouses ${TPCC_WAREHOUSE} -T ${TPCC_LOAD_THREADS} prepare

# break down to avoid 'server is busy' failure
TPCC_TABLES="item customer district orders new_order order_line history warehouse stock"
for i in $TPCC_TABLES; do
    echo analyzing table $i
    mysql -u root -h ${TIDB} -P 4000 --database="test" --execute="analyze table ${i};"
    sleep 1
done
echo analyze finished
# wait for pending compaction
sleep 60
./stop.sh
# tiup cluster stop ${TIUP_NAME}
sleep 5
./backup_cluster.sh ${1}
# backup metrics
