#!/bin/bash
source ~/variables.sh

go-tpc tpcc -T ${TPCC_THREADS} --warehouses ${TPCC_WAREHOUSE} --time ${TPCC_DURATION} run &>nohup.run
