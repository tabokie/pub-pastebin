#!/bin/bash
set -eof pipefail

source ~/variables.sh

if [ "${2}" = "all" ]; then
    tiup cluster stop ${TIUP_NAME} -y || true
    ./restore_cluster.sh ${1}
else
    tiup cluster stop ${TIUP_NAME} --role tikv -y || true
fi
./sync_tikv.sh ${1}
tiup cluster start ${TIUP_NAME}
