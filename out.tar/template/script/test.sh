#!/bin/bash
read -p "source device: " name
echo $name

