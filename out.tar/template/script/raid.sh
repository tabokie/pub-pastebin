# usage: raid.sh "nvme1n1 nvme2n1" /data
set -ueo pipefail

DEVICES=""
NUM_DEVICES=0
for i in $1; do
  DEVICES="${DEVICES} /dev/${i}"
  NUM_DEVICES=$((NUM_DEVICES + 1))
done
MNT=$2
sudo mkdir -p $MNT
sudo mdadm --create --verbose /dev/md0 --level=0 --name=myraid --raid-devices=${NUM_DEVICES} ${DEVICES}
sleep 2
sudo cat /proc/mdstat
sudo mkfs.ext4 /dev/md0 -L myraid
sudo mdadm --detail --scan | sudo tee -a /etc/mdadm.conf
sudo dracut -H -f /boot/initramfs-$(uname -r).img $(uname -r)
sudo mount -t ext4 LABEL=myraid $MNT -o defaults,barrier,nodelalloc,nodiratime,noatime

