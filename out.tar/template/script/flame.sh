#!/bin/bash
# usage: flame.sh NAME SEC

set -ueo pipefail

NAME=$1
if [ -z "$1" ]; then
    NAME="out"
fi
SECONDS=$2
if [ -z "$2" ]; then
    SECONDS=60
fi

./install.sh perf
./install.sh perl 
if [ ! -e stackcollapse-perf.pl ]; then
    wget https://raw.githubusercontent.com/brendangregg/FlameGraph/master/stackcollapse-perf.pl
    chmod 755 stackcollapse-perf.pl
fi
if [ ! -e flamegraph.pl ]; then
    wget https://raw.githubusercontent.com/brendangregg/FlameGraph/master/flamegraph.pl
    chmod 755 flamegraph.pl
fi
sudo perf record -F 99 -a -g -- sleep $SECONDS
sudo perf script | ./stackcollapse-perf.pl | ./flamegraph.pl > ${NAME}.svg

