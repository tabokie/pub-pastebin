#!/bin/bash
# usage: install centos-name [ubuntu-name]

CENTOS_NAME=$1
if [ -z "$2" ]; then
    UBUNTU_NAME=$1
else
    UBUNTU_NAME=$2
fi

sudo apt-get -v &> /dev/null && sudo apt-get update && sudo apt-get install -y $CENTOS_NAME
which yum &> /dev/null && sudo yum install -y $UBUNTU_NAME

