#!/bin/bash

set -ueo pipefail

source ./variables.sh

# modify config
cp topology_template.yaml control/topology.yaml
sed -i "s/TIDB_ADDR/${TIDB}/g" control/topology.yaml
for addr in ${TIKV}; do
    echo "  - host: ${addr}" >> control/topology.yaml
done

echo "Host ${TIDB_PUBLIC}
    User ${USER_NAME}
    IdentityFile ${SSH_KEY}" >> ~/.ssh/config
DB=${USER_NAME}@${TIDB_PUBLIC}
scp -3 ${SSH_KEY} $DB:~/
scp -3 ./*.sh $DB:~/
ssh $DB "~/setup_ondb.sh"
# for addr in ${TIKV_PUBLIC}; do
#     scp -3 ./setup_onkv.sh ${USER_NAME}@${addr}:~/
#     ssh -i ${SSH_KEY} ${USER_NAME}@${addr} "~/setup_onkv.sh"
# done
scp -3 -r control $DB:~/
scp -3 -r script $DB:~/

echo "please setup /data, /backup, /raft on kv server(s)"
