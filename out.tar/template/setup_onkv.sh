#!/bin/bash
set -ueo pipefail

sudo yum install -y vim git wget

source ~/.bash_profile
