#!/bin/bash
set -ueo pipefail

sudo apt-get -v &> /dev/null && sudo apt-get update && sudo apt-get install -y screen mysql-server vim wget git gcc
which yum &> /dev/null && sudo yum install -y screen mysql vim wget git gcc
# tiup
curl --proto '=https' --tlsv1.2 -sSf https://tiup-mirrors.pingcap.com/install.sh | sh
# go-tpc
curl --proto '=https' --tlsv1.2 -sSf https://raw.githubusercontent.com/pingcap/go-tpc/master/install.sh | sh
sleep 1

source ~/variables.sh
i=0
for addr in ${TIKV}; do
    echo "Host kv${i}
        Hostname ${addr}
        User ${USER_NAME}
        IdentityFile ${SSH_KEY}" >> ~/.ssh/config
    i=$((i+1))
done
sudo chmod 600 ~/.ssh/config
